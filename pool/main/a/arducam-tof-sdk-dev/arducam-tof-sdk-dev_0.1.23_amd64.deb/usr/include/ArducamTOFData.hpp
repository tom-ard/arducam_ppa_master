#pragma once
#include "ArducamTOFUnity.hpp"
namespace Arducam
{

/// @brief AbstractData
class ArducamFrameBuffer
{
  public:
#ifndef DOXYGEN_SHOULD_SKIP_THIS
    ArducamFrameBuffer() = default;
    virtual ~ArducamFrameBuffer() = default;

    virtual void updateTime(uint64_t timestamp) = 0;
#endif
    /**
     * @brief Get the Pointer of Frame Data.
     *
     * @param[in] type  Specify the frame data type.
     *   This parameter can be one of the following values:
     *     @arg RAW_FRAME
     *     @arg CONFIDENCE_FRAME
     *     @arg DEPTH_FRAME
     * @return Return Pointer of Frame Data.The returned pointer type can be one of the following type:
     *   - int16_t* : RAW_FRAME
     *   - float*   : DEPTH_FRAME
     *   - float*   : CONFIDENCE_FRAME
     */
    virtual void* getData(FrameType type) = 0;
    /**
     * @brief Specify the frame data type to get the frame data format.
     *
     * @param[in] type Specify the frame data type.
     *   This parameter can be one of the following values:
     *     @arg RAW_FRAME
     *     @arg CONFIDENCE_FRAME
     *     @arg DEPTH_FRAME
     * @param[out] format Returns the frame data format of the specified frame type
     * @return An ErrorCode.
     */
    virtual TofErrorCode getFormat(FrameType type, FrameFormat& format) = 0;
};
} // namespace Arducam
