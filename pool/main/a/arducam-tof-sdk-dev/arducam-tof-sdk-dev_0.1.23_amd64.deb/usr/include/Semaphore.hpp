#ifndef __SEMAPHORE_H
#define __SEMAPHORE_H

#include <condition_variable>
#include <cstdint>
#include <mutex>

class Semaphore
{
  public:
    explicit Semaphore(int max_count = 3) : _count(0), _max_count(max_count) {}

    void Signal()
    {
        std::unique_lock<std::mutex> lock(_mutex);

        if (_count <= _max_count) {
            ++_count;
            _cv.notify_all();
        }
    }
    bool Wait(int16_t ms = 20)
    {
        std::unique_lock<std::mutex> lock(_mutex);

        while (_count == 0) {
            if (ms < 0) {
                _cv.wait(lock, [=] { return _count > 0; });
            } else {
                if (_cv.wait_for(lock, std::chrono::milliseconds(ms), [=] { return _count > 0; }) == false)
                    return false;
            }
        }
        --_count;
        return true;
    }

    void cleanup()
    {
        std::unique_lock<std::mutex> lock(_mutex);
        _count = 0;
    }

  private:
    std::mutex _mutex;
    std::condition_variable _cv;
    volatile int _count;
    const int _max_count;
};
#endif