#ifndef __TOF_SENSOR_H
#define __TOF_SENSOR_H

#include "ArducamTOFUnity.hpp"

namespace Arducam
{
/**
 * @brief Direct operation class for camera/
 */
class ArducamTOFSensor
{
  public:
    /**
     * @brief the count of the frame needed to be fetched once.
     */
    int fetch_frame = 1;

  public:
    ArducamTOFSensor() = default;
    virtual ~ArducamTOFSensor() = default;

  public:
    /**
     * @brief Open the camera.
     *
     * @param[out] info Camera information.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode open(CameraInfo& info) = 0;

    /**
     * @brief Close camera.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode close() = 0;

    /**
     * @brief Start the camera stream.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode start() = 0;

    /**
     * @brief Stop camera stream.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode stop() = 0;

    /**
     * @brief Get camera information.
     */
    virtual CameraInfo getCameraInfo() const = 0;

    /**
     * @brief Read frame data from the camera.
     *
     * @param[out] data_ptr  Address of the frame data.
     * @param[out] timestamp The timestamp of the frame.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode getFrame(uint8_t* data_ptr, uint64_t& timestamp) = 0;

    /**
     * @brief Switch camera range.
     *
     * @param[in] mode  Mode type.
     * @param[in] value Mode value.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode setControl(Control mode, int value);

    /**
     * @brief get camera parameters.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode getControl(Control mode, int* value) const;

    /**
     * @brief Read register. (I2C)
     *
     * @param[in] addr Register address.
     * @param[out] val Register value.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode readReg(uint32_t addr, uint32_t& val) = 0;

    /**
     * @brief Write register. (I2C)
     *
     * @param[in] addr Register address.
     * @param[in] val Register value.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode writeReg(uint32_t addr, uint32_t val) = 0;

  protected:

    /**
     * @brief Set V4L2 control.
     * @param[in] id Control ID.
     * @param[in] value Control value.
     * @return An ErrorCode.
     *
     */
    virtual TofErrorCode v4l2_set_control(uint32_t id, int value) = 0;

    /**
     * @brief Get V4L2 control.
     * @param[in] id Control ID.
     * @param[out] value Control value.
     * @return An ErrorCode.
     */
    virtual TofErrorCode v4l2_get_control(uint32_t id, int& value) const = 0;

    /**
     * @brief Read register. (I2C ByPass with 16bit value)
     *
     * @param[in] addr Register address.
     * @param[out] val Register value.
     *
     * @return An ErrorCode.
     */
    TofErrorCode readCamera_16(uint32_t addr, uint32_t& val);

    /**
     * @brief Write register. (I2C ByPass with 16bit value)
     *
     * @param[in] addr Register address.
     * @param[in] val Register value.
     *
     * @return An ErrorCode.
     */
    TofErrorCode writeCamera_16(uint32_t addr, uint32_t val);

    TofErrorCode setExposure(int value);
    TofErrorCode getExposure(int* value) const;
    TofErrorCode getFramerate(int* value) const;
    TofErrorCode setFramerate(int value);
    TofErrorCode getHFlip(int* value) const;
    TofErrorCode setHFlip(int value);
    TofErrorCode getVFlip(int* value) const;
    TofErrorCode setVFlip(int value);
};

} // namespace Arducam

#endif
